import { motion } from "framer-motion";
import { Github, Linkedin, Mail, Phone } from "lucide-react";

export default function Portfolio() {
  return (
    <div className="min-h-screen bg-gray-100 text-gray-900">
      <header className="bg-white shadow-md p-6 flex justify-between items-center">
        <h1 className="text-2xl font-bold">Kolluri Shivaramakrishna</h1>
        <nav className="space-x-4">
          <a href="#about" className="hover:underline">About</a>
          <a href="#skills" className="hover:underline">Skills</a>
          <a href="#projects" className="hover:underline">Projects</a>
          <a href="#contact" className="hover:underline">Contact</a>
        </nav>
      </header>

      <main className="p-8">
        <section id="about" className="mb-12">
          <motion.div initial={{ opacity: 0, y: 50 }} animate={{ opacity: 1, y: 0 }}>
            <h2 className="text-xl font-semibold mb-2">About Me</h2>
            <p>
              I am a Frontend Developer with a strong foundation in React.js, Next.js, Java, and SQL.
              Passionate about building responsive web applications and interactive dashboards.
            </p>
          </motion.div>
        </section>

        <section id="skills" className="mb-12">
          <h2 className="text-xl font-semibold mb-2">Skills</h2>
          <ul className="grid grid-cols-2 md:grid-cols-3 gap-4">
            <li>HTML, CSS, JavaScript</li>
            <li>React.js, Next.js</li>
            <li>WordPress</li>
            <li>Java, Hibernate, Servlets</li>
            <li>MySQL</li>
            <li>Git, Maven</li>
          </ul>
        </section>

        <section id="projects" className="mb-12">
          <h2 className="text-xl font-semibold mb-2">Projects</h2>
          <ul className="list-disc list-inside">
            <li>Cybersecurity Dashboard (React.js, Next.js)</li>
            <li>School Data Management App (React.js, MySQL)</li>
            <li>Online Course Management (Java, Hibernate, MySQL)</li>
            <li>Portfolio Website (WordPress, HTML, CSS)</li>
          </ul>
        </section>

        <section id="contact">
          <h2 className="text-xl font-semibold mb-2">Contact</h2>
          <div className="flex space-x-4">
            <a href="mailto:kollurishivaramakrishna@gmail.com"><Mail /></a>
            <a href="tel:+918179374295"><Phone /></a>
            <a href="https://github.com/shiva141102" target="_blank" rel="noreferrer"><Github /></a>
            <a href="https://linkedin.com/in/kolluri-shivaramakrishna" target="_blank" rel="noreferrer"><Linkedin /></a>
          </div>
        </section>
      </main>
    </div>
  );
}
